# Diabetes regression results

- 353 training samples; 89 untouched test samples.
- Chosen alpha: 1.0; 5-fold training CV MAE: 45.00.
- Test MAE: 42.81; RMSE: 53.78; R-squared: 0.454.
- Mean-only baseline MAE: 64.01; RMSE: 73.22; R-squared: -0.012.

Target is the dataset's quantitative progression measure one year after baseline,
not a diabetes diagnosis, a probability or a treatment recommendation. MAE and RMSE are
in target-score units. This small historical benchmark cannot establish clinical validity.
Features are raw loader values, standardized only inside training folds. Hyperparameter
selection uses training CV; no test-driven tuning. Saved pipeline matches this evaluation.
Residual structure and error magnitude show why this is only a simple learning baseline.

![Evaluation](evaluation.png)
